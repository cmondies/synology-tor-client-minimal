"""
Graphs.
"""

__all__ = ["graphPanel", "bandwidthStats"]

